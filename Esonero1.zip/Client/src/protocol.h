/*
 * protocol.h
 * Author: Guillaume Desaphy
 *
 */

#ifndef PROTOCOL_H_
#define PROTOCOL_H_

#define NO_ERROR 0
#define PROTO_IP "127.0.0.1"
#define PROTO_PORT 57015

#endif /* PROTOCOL_H_ */
